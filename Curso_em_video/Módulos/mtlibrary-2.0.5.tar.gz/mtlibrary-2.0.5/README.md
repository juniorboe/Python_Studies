# MTLibrary 2.0
¡MTLibrary 2 esta aquí!

MTLibrary es una libreria en español desarrollada para resolver problemas matemáticos y así ayudar a esos programadores con bajos conocimientos con librerias en inglés.

### Algunas operaciones son:
- Suma
- Resta
- Multiplicación
- División
- Potencia
- Residuo
- Raíz cuadrada
- Porcentajes
- Área
- Radio de un circulo
- Y MUCHO MÁS

## Como utilizarlo
Acá te dejo un breve resumen de como utilizar el módulo.

### Puedes utilizar:
- suma
- resta
- multiplicación
- división
- residuo
- raiz
- radio
- area
- porcentaje
- potencia
- arcocoseno
- cosenoh
- seno_h
- tangente_a
- tangente_a2
- arcotangente_h
- redondear_arriba
- combinaciones
- copiar_signo
- coseno
- coseno_h
- angulos_radianes_g
- distancia
- error_print
- error_print_complementaria
- e_elevado
- e_elevado_1
- valor_absoluto
- factorial
- redendeo_abajo
- frexp
- suma_iterables
- gamma
- mayor_divisor_comun
- hipotenusa
- valores_cerca
- finito
- infinito
- es_nan
- redondar_raiz_abajo
- minimo_comun_multiplo
- multi_por_2_elevado_a_la_potencia_de_un_exponente
- logaritmo_natural_del_valor_absoluto
- log
- log10
- log1p
- log2

---
## Author
Este proyecto es construido por Estuardo Ramírez.

Encuentrame como @estuardodev en:

- GitHub
- Twitter
- Instagram
- Platzi
